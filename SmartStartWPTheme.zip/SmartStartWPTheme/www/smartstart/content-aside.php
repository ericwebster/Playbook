<div class="entry-body">

	<?php echo ss_framework_post_content(); ?>
	
</div><!-- end .entry-body -->

<div class="entry-meta">

	<?php echo ss_framework_post_meta(); ?>

</div><!-- end .entry-meta -->